Python 3.13.5 (tags/v3.13.5:6cb20a2, Jun 11 2025, 16:15:46) [MSC v.1943 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> 
============== RESTART: D:/Sem4/ml/lab/assignments/done/lab1_ml.py =============
pairs: 2
range: 8
matrix power:
[7, 10]
[15, 22]
highest character: p 3
mmm: [1, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 4, 4, 6, 6, 6, 6, 7, 8, 8, 8, 9, 9, 9, 10] 0.08 4 1
